#!/bin/bash

spkexe=./spk_nonmui
spkscr=in.diss_ads
outgif=diss_ads.gif
seed=1
xhi=20
yhi=10

# spparks executable
if [ ! -f $spkexe ]
then
  echo "ERROR: spparks executable $exec1 not found"
  echo "1. go to ~/GIT/FHDeX/exec/compressible_stag_mui/SPPARKS_MUI"
  echo "2. make nonmui"
  exit
fi

# generate sites data file "data.strips"
python create_site_file.py $xhi $yhi

# execute spparks
mpirun -np 1 $spkexe -in $spkscr -var seed $seed -var xhi $xhi -var yhi $yhi
echo "** spparks run completed"

# generate animated gif "diss_ads.gif"
echo "** converting jpg files into an animated gif"
convert *.jpg $outgif
echo "** animated gif will be shown"
animate $outgif & 
