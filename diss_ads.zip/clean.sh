#!/bin/bash

rm -rf data.strips log.spparks *.jpg *.gif
